<h1>Minecraft-Launch-P（WIP）</h1>

![](https://img.shields.io/badge/license-MIT-green)
![](https://img.shields.io/github/repo-size/Blessing-Studio/minecraft-launch-p)
![](https://img.shields.io/github/stars/Blessing-Studio/minecraft-launch-p)
![](https://img.shields.io/github/commit-activity/y/Blessing-Studio/minecraft-launch-p)

<h3><div>给 Python 程序开发者的全能、模块化的 Minecraft 启动核心</div></h3>

-------------------------------------------------------------

### 声明

+ 此项目为 [MinecraftLaunch](https://github.com/Blessing-Studio/MinecraftLaunch) 的 Python 版，负责人为 JustRainy，技术指导 YangSpring114
