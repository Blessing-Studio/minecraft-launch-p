from enum import Enum


class LaunchState(Enum):
    Success = 0
    Failed = 1
    Cancelled = 2
