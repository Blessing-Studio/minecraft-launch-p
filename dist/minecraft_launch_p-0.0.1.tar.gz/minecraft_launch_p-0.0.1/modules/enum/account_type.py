from enum import Enum


class AccountType(Enum):
    Offine = 1
    Microsoft = 2
    Yggdrasil = 3