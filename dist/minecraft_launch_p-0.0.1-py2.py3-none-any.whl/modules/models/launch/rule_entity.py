class RuleEntity():
    def __init__(self):
        self.action: str
        self.system: dict[str, str]