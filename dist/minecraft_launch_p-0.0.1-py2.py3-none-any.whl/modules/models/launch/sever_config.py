class SeverConfig():
    def __init__(self, port: int = 0, ip: str = None):
        self.port = port
        self.ip = ip
